# my-echo

echo のサンプルプログラム